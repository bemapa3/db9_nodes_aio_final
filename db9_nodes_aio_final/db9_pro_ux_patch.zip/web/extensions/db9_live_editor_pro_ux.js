app.registerExtension({
  name: "db9.live_editor.pro_ux",

  async setup(app) {
    const state = {
      sessionId: null,
      panel: null,
      minimized: false,
      autoOpen: true,
      lastNodeId: null,

      params: {
        exposure: 0, contrast: 0, highlights: 0, shadows: 0,
        whites: 0, blacks: 0, vibrance: 0, saturation: 0,
        temperature: 0, tint: 0, red_balance: 0, green_balance: 0,
        blue_balance: 0, curve_lift: 0, curve_gamma: 1, curve_gain: 1,
      },

      compare: {
        enabled: true,
        mode: "vertical",
        slicePosition: 0.5,
        swap: false,
        opacity: 1.0,
        differenceGain: 4.0,
        dragging: false,
      },

      autosave: {
        enabled: false,
        delayMs: 700,
        timer: null,
      },

      applyTimer: null,
    };

    function api(path, options = {}) {
      return fetch(path, {
        headers: { "Content-Type": "application/json" },
        ...options,
      });
    }

    function q(id) { return document.getElementById(id); }

    function updateStatus(text) {
      const el = q("db9-live-status");
      if (el) el.textContent = text;
    }

    function imgUrl(kind) {
      return `/db9/live_editor/session/${state.sessionId}/image?kind=${kind}&ts=${Date.now()}`;
    }

    function ensurePanelVisible() {
      if (!state.panel) return;
      state.panel.style.display = "block";
      state.minimized = false;
      const body = q("db9-live-body");
      if (body) body.style.display = "block";
    }

    function minimizePanel() {
      if (!state.panel) return;
      const body = q("db9-live-body");
      if (body) body.style.display = "none";
      state.minimized = true;
    }

    function toggleMinimize() {
      if (state.minimized) ensurePanelVisible();
      else minimizePanel();
    }

    function setPanelTitle(txt) {
      const el = q("db9-live-title");
      if (el) el.textContent = txt;
    }

    function getCompareElements() {
      return {
        wrap: q("db9-compare-wrap"),
        base: q("db9-compare-base"),
        top: q("db9-compare-top"),
        handle: q("db9-compare-handle"),
        diff: q("db9-compare-diff"),
      };
    }

    function getCompareUrls() {
      const a = state.compare.swap ? imgUrl("current") : imgUrl("reference");
      const b = state.compare.swap ? imgUrl("reference") : imgUrl("current");
      return { a, b };
    }

    async function renderDifferenceMode() {
      if (!state.sessionId) return;
      const r = await api(`/db9/live_editor/session/${state.sessionId}/compare`, {
        method: "POST",
        body: JSON.stringify({
          mode: "difference",
          split_position: state.compare.slicePosition,
          difference_gain: state.compare.differenceGain,
        }),
      });
      const j = await r.json();
      const { base, top, handle, diff } = getCompareElements();
      if (!j.ok) return;

      base.style.display = "none";
      top.style.display = "none";
      handle.style.display = "none";
      diff.style.display = "block";
      diff.src = j.compare_url;
    }

    function renderSliceMode() {
      const { base, top, handle, diff } = getCompareElements();
      const { a, b } = getCompareUrls();

      diff.style.display = "none";
      base.style.display = "block";
      top.style.display = "block";
      handle.style.display = state.compare.enabled ? "block" : "none";

      base.src = a;
      top.src = b;
      top.style.opacity = String(state.compare.opacity);

      if (!state.compare.enabled) {
        top.style.clipPath = "none";
        handle.style.display = "none";
        return;
      }

      const p = Math.max(0, Math.min(1, state.compare.slicePosition));

      if (state.compare.mode === "horizontal") {
        const topPercent = p * 100;
        top.style.clipPath = `inset(${topPercent}% 0 0 0)`;
        handle.style.left = "0";
        handle.style.right = "0";
        handle.style.top = `${topPercent}%`;
        handle.style.bottom = "auto";
        handle.style.width = "100%";
        handle.style.height = "2px";
        handle.style.cursor = "ns-resize";
      } else {
        const leftPercent = p * 100;
        top.style.clipPath = `inset(0 0 0 ${leftPercent}%)`;
        handle.style.top = "0";
        handle.style.bottom = "0";
        handle.style.left = `${leftPercent}%`;
        handle.style.right = "auto";
        handle.style.width = "2px";
        handle.style.height = "100%";
        handle.style.cursor = "ew-resize";
      }
    }

    async function renderCompare() {
      if (!state.sessionId) return;
      if (state.compare.mode === "difference") {
        await renderDifferenceMode();
      } else {
        renderSliceMode();
      }
    }

    function debounceAutosave() {
      if (!state.autosave.enabled || !state.sessionId) return;
      clearTimeout(state.autosave.timer);
      state.autosave.timer = setTimeout(async () => {
        const r = await api(`/db9/live_editor/session/${state.sessionId}/autosave`, {
          method: "POST",
          body: JSON.stringify({ reason: "debounced" }),
        });
        const j = await r.json();
        updateStatus(`Autosaved: ${j.saved_path || "ok"}`);
      }, state.autosave.delayMs);
    }

    function scheduleApply() {
      if (state.applyTimer) return;
      state.applyTimer = setTimeout(async () => {
        state.applyTimer = null;
        if (!state.sessionId) return;

        const r = await api(`/db9/live_editor/session/${state.sessionId}/apply`, {
          method: "POST",
          body: JSON.stringify({ params: state.params }),
        });
        const j = await r.json();

        if (j.ok) {
          const editedImg = q("db9-live-edited");
          if (editedImg) editedImg.src = j.preview_url;
          await renderCompare();
          debounceAutosave();
          updateStatus("Preview updated");
        } else {
          updateStatus("Apply failed");
        }
      }, 80);
    }

    function row() {
      const d = document.createElement("div");
      d.style.cssText = "display:flex;gap:8px;align-items:center;margin:4px 0;";
      return d;
    }

    function sectionTitle(text) {
      const h = document.createElement("div");
      h.textContent = text;
      h.style.cssText = "margin:10px 0 4px 0;font-weight:700;font-size:13px;opacity:0.95;";
      return h;
    }

    function button(text, onClick, style="") {
      const b = document.createElement("button");
      b.textContent = text;
      b.style.cssText = `padding:6px 10px;border-radius:8px;border:1px solid #444;background:#26262b;color:#fff;${style}`;
      b.onclick = onClick;
      return b;
    }

    function slider(label, key, min, max, step, value, onChange = null, id = null) {
      const wrap = document.createElement("div");
      wrap.style.cssText = "display:flex;flex-direction:column;gap:2px;margin:6px 0;";

      const top = row();
      const lab = document.createElement("label");
      lab.textContent = label;
      lab.style.flex = "1";
      lab.style.fontSize = "12px";

      const val = document.createElement("span");
      const valId = `db9-val-${id || key || label.replace(/\s+/g, "-").toLowerCase()}`;
      val.id = valId;
      val.textContent = String(value);
      val.style.minWidth = "56px";
      val.style.textAlign = "right";
      val.style.fontSize = "12px";

      const input = document.createElement("input");
      input.type = "range";
      input.min = String(min);
      input.max = String(max);
      input.step = String(step);
      input.value = String(value);
      input.style.width = "100%";
      if (id || key) input.id = `db9-slider-${id || key}`;

      input.oninput = async () => {
        const v = parseFloat(input.value);
        val.textContent = input.value;
        if (onChange) {
          await onChange(v);
        } else {
          state.params[key] = v;
          scheduleApply();
        }
      };

      top.append(lab, val);
      wrap.append(top, input);
      return wrap;
    }

    function checkbox(label, value, onChange, id=null) {
      const wrap = row();
      const lab = document.createElement("label");
      lab.textContent = label;
      lab.style.flex = "1";
      lab.style.fontSize = "12px";

      const input = document.createElement("input");
      input.type = "checkbox";
      input.checked = !!value;
      if (id) input.id = id;
      input.onchange = () => onChange(input.checked);

      wrap.append(lab, input);
      return wrap;
    }

    function select(label, options, current, onChange, id=null) {
      const wrap = row();
      const lab = document.createElement("label");
      lab.textContent = label;
      lab.style.flex = "1";
      lab.style.fontSize = "12px";

      const sel = document.createElement("select");
      if (id) sel.id = id;
      sel.style.cssText = "background:#26262b;color:#fff;border:1px solid #444;border-radius:6px;padding:4px 6px;";
      options.forEach(v => {
        const o = document.createElement("option");
        o.value = v;
        o.textContent = v;
        if (v === current) o.selected = true;
        sel.appendChild(o);
      });

      sel.onchange = () => onChange(sel.value);
      wrap.append(lab, sel);
      return wrap;
    }

    async function saveNow() {
      if (!state.sessionId) return;
      const prefix = q("db9-live-prefix")?.value || "DB9_Live_Edit";
      const saveMode = q("db9-live-save-mode")?.value || "versioned";
      const fmt = q("db9-live-format")?.value || "PNG";
      const qv = parseInt(q("db9-live-jpeg-q")?.value || "95");

      const r = await api(`/db9/live_editor/session/${state.sessionId}/save`, {
        method: "POST",
        body: JSON.stringify({ filename_prefix: prefix, save_mode: saveMode, output_format: fmt, jpeg_quality: qv }),
      });
      const j = await r.json();
      updateStatus(`Saved: ${j.saved_path || "ok"}`);
    }

    async function resetEditor() {
      if (!state.sessionId) return;
      const r = await api(`/db9/live_editor/session/${state.sessionId}/reset`, {
        method: "POST",
        body: JSON.stringify({}),
      });
      const j = await r.json();

      if (j.ok) {
        Object.assign(state.params, {
          exposure: 0, contrast: 0, highlights: 0, shadows: 0, whites: 0, blacks: 0,
          vibrance: 0, saturation: 0, temperature: 0, tint: 0,
          red_balance: 0, green_balance: 0, blue_balance: 0,
          curve_lift: 0, curve_gamma: 1, curve_gain: 1,
        });

        [
          ["exposure", 0], ["contrast", 0], ["highlights", 0], ["shadows", 0],
          ["whites", 0], ["blacks", 0], ["vibrance", 0], ["saturation", 0],
          ["temperature", 0], ["tint", 0], ["red_balance", 0], ["green_balance", 0],
          ["blue_balance", 0], ["curve_lift", 0], ["curve_gamma", 1], ["curve_gain", 1]
        ].forEach(([k, v]) => {
          const s = q(`db9-slider-${k}`);
          const val = q(`db9-val-${k}`);
          if (s) s.value = String(v);
          if (val) val.textContent = String(v);
        });

        const edited = q("db9-live-edited");
        if (edited) edited.src = j.preview_url;
        await renderCompare();
        updateStatus("Reset");
      }
    }

    async function closeEditor() {
      if (state.sessionId) {
        await api(`/db9/live_editor/session/${state.sessionId}/close`, {
          method: "POST",
          body: JSON.stringify({}),
        });
      }
      if (state.panel) state.panel.remove();
      state.panel = null;
      state.sessionId = null;
      state.lastNodeId = null;
    }

    function attachCompareDrag() {
      const { wrap, handle } = getCompareElements();
      if (!wrap || !handle) return;

      const updateFromMouse = (e) => {
        const rect = wrap.getBoundingClientRect();
        if (state.compare.mode === "horizontal") {
          const y = (e.clientY - rect.top) / rect.height;
          state.compare.slicePosition = Math.max(0, Math.min(1, y));
        } else {
          const x = (e.clientX - rect.left) / rect.width;
          state.compare.slicePosition = Math.max(0, Math.min(1, x));
        }
        const sliderEl = q("db9-slider-compare-slice");
        const valEl = q("db9-val-compare-slice");
        if (sliderEl) sliderEl.value = String(state.compare.slicePosition);
        if (valEl) valEl.textContent = state.compare.slicePosition.toFixed(2);
        renderCompare();
      };

      handle.onmousedown = (e) => {
        e.preventDefault();
        state.compare.dragging = true;
      };

      wrap.onmousedown = (e) => {
        if (!state.compare.enabled || state.compare.mode === "difference") return;
        state.compare.dragging = true;
        updateFromMouse(e);
      };

      window.addEventListener("mousemove", (e) => {
        if (!state.compare.dragging) return;
        updateFromMouse(e);
      });

      window.addEventListener("mouseup", () => {
        state.compare.dragging = false;
      });
    }

    function buildComparePreview() {
      const wrap = document.createElement("div");
      wrap.id = "db9-compare-wrap";
      wrap.style.cssText = `
        position: relative; width: 100%; aspect-ratio: 16 / 9; margin-top: 8px;
        border-radius: 10px; border: 1px solid #333; overflow: hidden; background: #111;
      `;

      const base = document.createElement("img");
      base.id = "db9-compare-base";
      base.style.cssText = "position:absolute; inset:0; width:100%; height:100%; object-fit:contain; user-select:none; pointer-events:none;";

      const top = document.createElement("img");
      top.id = "db9-compare-top";
      top.style.cssText = "position:absolute; inset:0; width:100%; height:100%; object-fit:contain; user-select:none; pointer-events:none;";

      const diff = document.createElement("img");
      diff.id = "db9-compare-diff";
      diff.style.cssText = "position:absolute; inset:0; width:100%; height:100%; object-fit:contain; display:none; user-select:none; pointer-events:none;";

      const handle = document.createElement("div");
      handle.id = "db9-compare-handle";
      handle.style.cssText = "position:absolute; background:#ffd84d; box-shadow:0 0 0 1px rgba(0,0,0,0.35); z-index:5;";

      const badge = document.createElement("div");
      badge.id = "db9-compare-badge";
      badge.style.cssText = "position:absolute; left:10px; top:10px; z-index:6; background:rgba(0,0,0,0.5); color:#fff; padding:4px 8px; border-radius:999px; font-size:12px;";
      badge.textContent = "Original | Edited";

      wrap.append(base, top, diff, handle, badge);
      return wrap;
    }

    function buildPanel() {
      const panel = document.createElement("div");
      panel.id = "db9-live-editor-panel";
      panel.style.cssText = `
        position:fixed; right:18px; top:56px; width:560px; max-height:88vh; overflow:auto;
        background:#1b1b1f; color:#fff; border:1px solid #444; border-radius:14px; padding:12px;
        z-index:999999; box-shadow:0 10px 30px rgba(0,0,0,0.35);
      `;

      const header = row();
      header.style.justifyContent = "space-between";

      const title = document.createElement("div");
      title.id = "db9-live-title";
      title.textContent = "DB9 Live Tone Editor";
      title.style.cssText = "font-weight:700;font-size:16px;";

      const headBtns = row();
      headBtns.append(
        button("−", toggleMinimize, "width:32px;padding:4px 0;"),
        button("×", closeEditor, "width:32px;padding:4px 0;")
      );
      header.append(title, headBtns);

      const status = document.createElement("div");
      status.id = "db9-live-status";
      status.style.cssText = "font-size:12px;opacity:0.85;margin-bottom:8px;";
      status.textContent = "Idle";

      const body = document.createElement("div");
      body.id = "db9-live-body";

      const actions = row();
      actions.append(
        button("Save Now", saveNow),
        button("Reset", resetEditor),
        checkbox("Auto Open", true, (v) => { state.autoOpen = v; }, "db9-auto-open"),
      );

      const autos = row();
      const autosLabel = document.createElement("label");
      autosLabel.textContent = "Autosave";
      autosLabel.style.flex = "1";
      autosLabel.style.fontSize = "12px";
      const autosCheck = document.createElement("input");
      autosCheck.type = "checkbox";
      autosCheck.id = "db9-live-autosave-check";
      autosCheck.onchange = () => { state.autosave.enabled = autosCheck.checked; };
      const autosDelay = document.createElement("input");
      autosDelay.type = "number";
      autosDelay.value = "700";
      autosDelay.min = "100";
      autosDelay.max = "5000";
      autosDelay.id = "db9-live-autosave-delay";
      autosDelay.style.width = "90px";
      autosDelay.onchange = () => { state.autosave.delayMs = parseInt(autosDelay.value || "700"); };
      autos.append(autosLabel, autosCheck, autosDelay);

      const prefixRow = row();
      const prefixLabel = document.createElement("label");
      prefixLabel.textContent = "Filename";
      prefixLabel.style.flex = "1";
      prefixLabel.style.fontSize = "12px";
      const prefixInput = document.createElement("input");
      prefixInput.id = "db9-live-prefix";
      prefixInput.value = "DB9_Live_Edit";
      prefixInput.style.cssText = "background:#26262b;color:#fff;border:1px solid #444;border-radius:6px;padding:4px 6px;flex:1;";
      prefixRow.append(prefixLabel, prefixInput);

      const modeRow = row();
      const modeLabel = document.createElement("label");
      modeLabel.textContent = "Save Mode";
      modeLabel.style.flex = "1";
      modeLabel.style.fontSize = "12px";
      const modeSelect = document.createElement("select");
      modeSelect.id = "db9-live-save-mode";
      modeSelect.style.cssText = "background:#26262b;color:#fff;border:1px solid #444;border-radius:6px;padding:4px 6px;";
      ["versioned", "overwrite"].forEach(v => {
        const o = document.createElement("option");
        o.value = v;
        o.textContent = v;
        modeSelect.appendChild(o);
      });
      modeRow.append(modeLabel, modeSelect);

      const fmtRow = row();
      const fmtLabel = document.createElement("label");
      fmtLabel.textContent = "Format";
      fmtLabel.style.flex = "1";
      fmtLabel.style.fontSize = "12px";
      const fmt = document.createElement("select");
      fmt.id = "db9-live-format";
      fmt.style.cssText = "background:#26262b;color:#fff;border:1px solid #444;border-radius:6px;padding:4px 6px;";
      ["PNG", "JPEG", "WEBP"].forEach(v => {
        const o = document.createElement("option");
        o.value = v;
        o.textContent = v;
        fmt.appendChild(o);
      });
      const qv = document.createElement("input");
      qv.id = "db9-live-jpeg-q";
      qv.type = "number";
      qv.value = "95";
      qv.min = "1";
      qv.max = "100";
      qv.style.cssText = "width:70px;background:#26262b;color:#fff;border:1px solid #444;border-radius:6px;padding:4px 6px;";
      fmtRow.append(fmtLabel, fmt, qv);

      const refHeader = sectionTitle("Reference / Edited");
      const orig = document.createElement("img");
      orig.id = "db9-live-original";
      orig.style.cssText = "width:100%;margin-top:8px;border-radius:8px;border:1px solid #333;";
      const edited = document.createElement("img");
      edited.id = "db9-live-edited";
      edited.style.cssText = "width:100%;margin-top:8px;border-radius:8px;border:1px solid #333;";

      const compareHeader = sectionTitle("Slice Compare");
      const compareWrap = buildComparePreview();

      body.append(
        actions, autos, prefixRow, modeRow, fmtRow,
        refHeader, orig, edited,
        compareHeader,
        checkbox("Enable Slice Compare", true, async (v) => { state.compare.enabled = v; await renderCompare(); }, "db9-compare-enabled"),
        checkbox("Swap Original / Edited", false, async (v) => { state.compare.swap = v; await renderCompare(); }, "db9-compare-swap"),
        select("Compare Mode", ["vertical", "horizontal", "difference"], "vertical", async (v) => { state.compare.mode = v; await renderCompare(); }, "db9-compare-mode"),
        slider("Slice Position", null, 0, 1, 0.01, 0.5, async (v) => { state.compare.slicePosition = v; await renderCompare(); }, "compare-slice"),
        slider("Top Opacity", null, 0, 1, 0.01, 1.0, async (v) => { state.compare.opacity = v; await renderCompare(); }, "compare-opacity"),
        slider("Difference Gain", null, 1, 16, 0.1, 4.0, async (v) => { state.compare.differenceGain = v; if (state.compare.mode === "difference") await renderCompare(); }, "compare-diff"),
        compareWrap,
        sectionTitle("Light"),
        slider("Exposure", "exposure", -2, 2, 0.01, 0),
        slider("Contrast", "contrast", -1, 1, 0.01, 0),
        slider("Highlights", "highlights", -1, 1, 0.01, 0),
        slider("Shadows", "shadows", -1, 1, 0.01, 0),
        slider("Whites", "whites", -1, 1, 0.01, 0),
        slider("Blacks", "blacks", -1, 1, 0.01, 0),
        sectionTitle("Color"),
        slider("Vibrance", "vibrance", -1, 1, 0.01, 0),
        slider("Saturation", "saturation", -1, 1, 0.01, 0),
        slider("Temperature", "temperature", -1, 1, 0.01, 0),
        slider("Tint", "tint", -1, 1, 0.01, 0),
        slider("Red Balance", "red_balance", -1, 1, 0.01, 0),
        slider("Green Balance", "green_balance", -1, 1, 0.01, 0),
        slider("Blue Balance", "blue_balance", -1, 1, 0.01, 0),
        sectionTitle("Curve"),
        slider("Curve Lift", "curve_lift", -1, 1, 0.01, 0),
        slider("Curve Gamma", "curve_gamma", 0.2, 3.0, 0.01, 1.0),
        slider("Curve Gain", "curve_gain", 0.2, 3.0, 0.01, 1.0)
      );

      panel.append(header, status, body);
      document.body.appendChild(panel);
      state.panel = panel;
      attachCompareDrag();
    }

    function syncWidgetValue(node, name, fallback=null) {
      const widgets = node?.widgets || [];
      const w = widgets.find(x => x.name === name);
      return w ? w.value : fallback;
    }

    function findSessionId(node) {
      return syncWidgetValue(node, "session_id", null);
    }

    function syncNodeSettingsToPanel(node) {
      if (!node) return;
      const prefix = syncWidgetValue(node, "filename_prefix", "DB9_Live_Edit");
      const autosave = !!syncWidgetValue(node, "autosave", false);
      const autosaveDelay = syncWidgetValue(node, "autosave_delay_ms", 700);
      const saveMode = syncWidgetValue(node, "save_mode", "versioned");
      const outputFormat = syncWidgetValue(node, "output_format", "PNG");
      const jpegQuality = syncWidgetValue(node, "jpeg_quality", 95);

      if (q("db9-live-prefix")) q("db9-live-prefix").value = prefix;
      if (q("db9-live-autosave-check")) q("db9-live-autosave-check").checked = autosave;
      if (q("db9-live-autosave-delay")) q("db9-live-autosave-delay").value = String(autosaveDelay);
      if (q("db9-live-save-mode")) q("db9-live-save-mode").value = saveMode;
      if (q("db9-live-format")) q("db9-live-format").value = outputFormat;
      if (q("db9-live-jpeg-q")) q("db9-live-jpeg-q").value = String(jpegQuality);

      state.autosave.enabled = autosave;
      state.autosave.delayMs = parseInt(String(autosaveDelay || 700));
    }

    async function openEditor(sessionId, node=null) {
      state.sessionId = sessionId;
      state.lastNodeId = node?.id ?? null;

      if (!state.panel) buildPanel();
      ensurePanelVisible();

      if (node) syncNodeSettingsToPanel(node);
      setPanelTitle(node ? `DB9 Live Tone Editor • Node ${node.id}` : "DB9 Live Tone Editor");

      const r = await api("/db9/live_editor/session/init", {
        method: "POST",
        body: JSON.stringify({ session_id: sessionId }),
      });
      const j = await r.json();

      if (!j.ok) {
        updateStatus("Session init failed");
        return;
      }

      q("db9-live-original").src = imgUrl("reference");
      q("db9-live-edited").src = imgUrl("current");

      await renderCompare();
      updateStatus(`Session ${sessionId} ready`);
    }

    function installNodeUX(node) {
      const title = node.comfyClass || node.type || "";
      if (!title.includes("DB9 Live Tone Editor")) return;

      const originalOnExecuted = node.onExecuted;
      node.onExecuted = function(...args) {
        if (originalOnExecuted) originalOnExecuted.apply(this, args);
        const sid = findSessionId(node);
        if (sid && state.autoOpen) {
          setTimeout(() => openEditor(sid, node), 150);
        }
      };

      if (!node.__db9LiveBtnAdded) {
        node.addWidget("button", "Open Live Editor", null, () => {
          const sid = findSessionId(node);
          if (sid) openEditor(sid, node);
          else updateStatus("Run the node first to create session_id");
        });
        node.__db9LiveBtnAdded = true;
      }
    }

    const origNodeAdded = app.graph.onNodeAdded;
    app.graph.onNodeAdded = function(node) {
      if (origNodeAdded) origNodeAdded.call(this, node);
      installNodeUX(node);
    };

    const origMenu = LiteGraph.LGraphNode.prototype.getExtraMenuOptions;
    LiteGraph.LGraphNode.prototype.getExtraMenuOptions = function(_, options) {
      options = origMenu ? (origMenu.apply(this, arguments) || options || []) : (options || []);
      const title = this.comfyClass || this.type || "";

      if (title.includes("DB9 Live Tone Editor")) {
        options.push({
          content: "Open DB9 Live Editor",
          callback: () => {
            const sid = findSessionId(this);
            if (sid) openEditor(sid, this);
            else updateStatus("Run the node first to create session_id");
          }
        });
        options.push({
          content: "Toggle Auto Open",
          callback: () => {
            state.autoOpen = !state.autoOpen;
            const autoEl = q("db9-auto-open");
            if (autoEl) autoEl.checked = state.autoOpen;
            updateStatus(`Auto Open: ${state.autoOpen ? "ON" : "OFF"}`);
          }
        });
      }
      return options;
    };
  }
});
