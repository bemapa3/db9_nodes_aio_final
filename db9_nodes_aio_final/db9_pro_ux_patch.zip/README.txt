DB9 Pro UX patch
- auto open editor after node execute
- built-in node button
- persistent floating panel
- minimize / close
- live slice compare
- sync node widget values into panel
